import React from 'react'
import { Button } from 'react-bootstrap'
function four() {
  return (
    <main className='char'>
      <div className='noti'>
        <h1> 404</h1>
        <h2>Page not found</h2>

 <Button variant="dark" className="banner-button all-same-ani" href="/">
                  Go Back To Home
                </Button>

      </div>
    </main>

  )
}

export default four